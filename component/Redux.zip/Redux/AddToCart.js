import React, { Component } from 'react'
import {
    Text, View, FlatList, TouchableOpacity, StyleSheet, Image,
} from 'react-native'
import { connect } from 'react-redux'
import { Card } from 'react-native-shadow-cards';
import { delVeg } from '../Redux/Action'
import LinearGradient from 'react-native-linear-gradient'
class AddToCart extends Component {
    render() {
        console.log("Add to Cart:", this.props.vegetables)
        return (
            <View style={{ flex: 1 }}>
                <LinearGradient
                    colors={['#33ccff', '#ff99cc']}
                    style={styles.container}
                    start={{ x: 0, y: 0 }}
                    end={{ x: 1, y: 1 }}>
                    <FlatList
                        contentContainerStyle={{ paddingBottom: 100 }}
                        data={this.props.vegetables}
                        renderItem={({ item, index }) =>
                            <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                                <Card style={{ padding: 10, margin: 15, borderRadius: 20 }}>
                                    <View style={{ flexDirection: 'row', justifyContent:'space-evenly' }}>
                                        <Image
                                            style={styles.img}
                                            source={require('../Images/veg.jpg')}
                                        />
                                        <View style={{ flexDirection: 'column' }}>
                                            <Text style={styles.textStyle}>Name:{item.item}</Text>
                                            <Text style={styles.textStyle}>Qantity:{item.quantity}</Text>
                                            <Text style={styles.textStyle}>Price:₹{item.price}</Text>
                                            
                                        </View>
                                    </View>
                                    

                                </Card>
                            </View>
                        }></FlatList>
                </LinearGradient>
            </View>
        )
    }
}
const mapStateToProps = state => {
    return {
        vegetables: state.cart.vegetables,
    }
}

const mapDispatchToProps = dispatch => {
    return {
        removeVeg: (id) => dispatch(delVeg(id))
    }
}

const styles = StyleSheet.create({
    container: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
    },
    container1: {
        flex: 1,
        alignItems: 'center',
        justifyContent: 'center',
        borderRadius: 25
    },
    textStyle: {
        fontSize: 24,
        fontWeight: 'bold',
        textAlign: 'center',
        color: 'teal',
    },
    img: {
        width: 120,
        height: 120
    },
    increBtn: {
        fontSize: 32,
        fontWeight: 'bold',
        backgroundColor: '#a1063f',
        color: 'white',
        textAlign: 'center',
        borderRadius: 25
    }
})
export default connect(mapStateToProps, mapDispatchToProps)(AddToCart)
