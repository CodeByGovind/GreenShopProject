import { VEGETABLE_LIST, VEGETABLE_ERROR, VEGETABLE_REQUEST }
    from '../Types/VegetableType'
import axios from 'axios'
const vegRequest = () => {
    return {
        type: VEGETABLE_REQUEST
    }
}
const vegSuccess = (list) => {
    return {
        type: VEGETABLE_LIST,
        payload: list
    }
}
const vegError = (error) => {
    return {
        type: VEGETABLE_ERROR,
        payload: error
    }
}

export const Vegetables = () => {
    return function (dispatch) {
        dispatch(vegRequest())
        axios.get("http://tomatoman.pythonanywhere.com/items/items/")
            .then((response) => {
                // console.log(response.data)
                const data = response.data.map((cat)=>({
                    ...cat,
                    id:Math.random(),
                    quantity:1
                }))
                dispatch(vegSuccess(data))
            })
            .catch((error) => {
                console.log(error)
                dispatch(vegError(error))
            })
    }
}